import Register from "./register.container";

export default Register;