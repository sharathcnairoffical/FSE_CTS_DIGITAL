package com.tweetapp.tweetapp.exception;

public class UsernameAlreadyExists extends Exception{

    public UsernameAlreadyExists(String msg) {
        super(msg);
    }
}
