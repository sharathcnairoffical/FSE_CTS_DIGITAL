package com.tweetapp.TweetApp.service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweetapp.TweetApp.dto.ReplyDto;
import com.tweetapp.TweetApp.dto.TweetRequest;
import com.tweetapp.TweetApp.dto.TweetResponse;
import com.tweetapp.TweetApp.dto.TweetsDto;
import com.tweetapp.TweetApp.model.Tweet;
import com.tweetapp.TweetApp.repository.TweetRepository;

@Service
public class TweetServiceImpl implements TweetService {
	
	@Autowired
	TweetRepository tweetRepo;
	
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM-dd-yyyy");
	SimpleDateFormat localDateFormat = new SimpleDateFormat("HH:mm:ss");

	@Override
	public TweetResponse getAllTweets() {
		// TODO Auto-generated method stub
		TweetResponse response = new TweetResponse();
		List<Tweet> tweets = tweetRepo.findAll();
		List<TweetsDto> tweetsDto = new ArrayList<>();
		tweets.forEach(entity -> {
			TweetsDto tweet = new TweetsDto();
			tweet.setTweet(entity.getTweet());
			tweet.setTweetId(entity.getTweetId());
			tweet.setUserTweetId(entity.getUserTweetId());
			tweet.setLike(entity.getLike());
			tweet.setReply(entity.getReply());
			tweet.setDateOfPost(simpleDateFormat.format(entity.getDateOfPost()));
			tweet.setTimeOfPost(localDateFormat.format(entity.getDateOfPost()));
			//tweet.setDateOfPost(entity.getDateOfPost());
			//tweet.setTimeOfPost(entity.getDateOfPost());
			tweetsDto.add(tweet);
		});
		response.setTweetsDto(tweetsDto);
		return response;
	}

	@Override
	public TweetResponse getAllTweetsByUserName(String userName) {
		// TODO Auto-generated method stub
		TweetResponse response = new TweetResponse();
		List<TweetsDto> tweetsDto = new ArrayList<>();
		try {
			List<Tweet> tweets = tweetRepo.findByUserName(userName);
			tweets.forEach(entities->{
				TweetsDto dto = new TweetsDto();
				dto.setTweet(entities.getTweet());
				dto.setLike(entities.getLike());
				dto.setReply(entities.getReply());
				dto.setTweetId(entities.getTweetId());
				dto.setUserTweetId(entities.getUserTweetId());
				dto.setDateOfPost(simpleDateFormat.format(entities.getDateOfPost()));
				dto.setTimeOfPost(localDateFormat.format(entities.getDateOfPost()));
				tweetsDto.add(dto);
			});
			response.setStatusMessage("SUCCESS");
			response.setTweetsDto(tweetsDto);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public TweetResponse addTweet(TweetRequest request, String userName) {
		// TODO Auto-generated method stub
		TweetResponse response = new TweetResponse();
		TweetsDto tweet = request.getTweet();
		Tweet entity = new Tweet();
		List<ReplyDto> reply = new ArrayList<>();
		Tweet maxEntity = tweetRepo.findTopByOrderByTweetIdDesc();
		if(maxEntity == null)
		{
			entity.setTweetId(1l);
		}
		else
		{
			entity.setTweetId(maxEntity.getTweetId()+1);
		}
		entity.setTweet(tweet.getTweet());
		entity.setUserTweetId(userName);
		entity.setLike(0l);
		entity.setReply(reply);
		entity.setDateOfPost(new Date());
		try {
			tweetRepo.save(entity);
			response.setStatusMessage("SUCCESS");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			response.setStatusMessage("FAILURE");
		}
		return response;
	}

	@Override
	public TweetResponse deleteTweet(String userName, Long tweetId) {
		// TODO Auto-generated method stub
		TweetResponse response = new TweetResponse();
		try {
			tweetRepo.deleteById(tweetId);
			response.setStatusMessage("SUCCESS");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			response.setStatusMessage("FAILED");
		}
		return response;
	}

	@Override
	public TweetResponse replyToTweet(TweetRequest request) {
		// TODO Auto-generated method stub
		TweetResponse response = new TweetResponse();
		TweetsDto dto = request.getTweet();
		List<ReplyDto> replies = new ArrayList<>();
		try {
			Tweet entity = tweetRepo.findByTweetId(dto.getTweetId());
			replies.addAll(entity.getReply());
			List<ReplyDto> newReplies = dto.getReply();
			newReplies.forEach(reply->{
				reply.setDateReplied(new Date());
			});
			replies.addAll(newReplies);
			entity.setReply(replies);
			tweetRepo.save(entity);
			response.setStatusMessage("SUCCESS");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			response.setStatusMessage("FAILED");
		}
		return response;
	}

	@Override
	public TweetResponse likeATweet(TweetRequest request) {
		// TODO Auto-generated method stub
		TweetResponse response = new TweetResponse();
		TweetsDto dto = request.getTweet();
		try {
			Tweet entity = tweetRepo.findByTweetId(dto.getTweetId());
			entity.setLike(entity.getLike()+1);
			tweetRepo.save(entity);
			response.setStatusMessage("SUCCESS");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			response.setStatusMessage("FAILED");
		}
		return response;
	}

	@Override
	public TweetResponse updateTweet(TweetRequest request) {
		// TODO Auto-generated method stub
		TweetResponse response = new TweetResponse();
		TweetsDto dto = request.getTweet();
		try {
			Tweet entity = tweetRepo.findByTweetId(dto.getTweetId());
			entity.setTweet(dto.getTweet());
			tweetRepo.save(entity);
			response.setStatusMessage("SUCCESS");	
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			response.setStatusMessage("FAILED");
		}
		return response;
	}

}
