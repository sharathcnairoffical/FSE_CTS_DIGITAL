package com.tweetapp.TweetApp.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.tweetapp.TweetApp.model.UserRoles;
import com.tweetapp.TweetApp.repository.UserRepository;


@Service
public class AppUserDetailsService implements UserDetailsService {

	@Autowired
	UserRepository userRepo;

	public UserDetails loadUserByUsername(String loginId) throws UsernameNotFoundException {
		UserRoles userRoles = userRepo.findByLoginId(loginId);
		if (userRoles.getLoginId() == null) {
			throw new UsernameNotFoundException(loginId);
		} else {
			AppUser appUser = new AppUser(userRoles);
			return appUser;
		}
	}
}
