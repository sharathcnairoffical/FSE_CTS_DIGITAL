package com.tweetapp.TweetApp.dto;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TweetsDto {
	private String tweet;

	private String userTweetId;

	private Long tweetId;
	
	private Long like;
	
	private List<ReplyDto> reply;
	
	private String dateOfPost;
	
	private String timeOfPost;


	
}
