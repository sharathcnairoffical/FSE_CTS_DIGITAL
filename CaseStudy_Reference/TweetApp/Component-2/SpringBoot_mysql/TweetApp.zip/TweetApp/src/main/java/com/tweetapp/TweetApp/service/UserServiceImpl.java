package com.tweetapp.TweetApp.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.tweetapp.TweetApp.dto.UserRequest;
import com.tweetapp.TweetApp.dto.UserResponse;
import com.tweetapp.TweetApp.dto.UsersDto;
import com.tweetapp.TweetApp.model.UserRoles;
import com.tweetapp.TweetApp.repository.UserRepository;

@Service
public class UserServiceImpl  implements UserService{

	@Autowired
	UserRepository usersRepo;
	
	@Override
	public UserResponse getAllUsers() {
		// TODO Auto-generated method stub
		UserResponse response = new UserResponse();
		try {
			List<UserRoles> userRoles = usersRepo.findAll();
			List<UsersDto> usersDto = new ArrayList<>();
			userRoles.forEach(entity -> {
				UsersDto dto = new UsersDto();
				dto.setContactNumber(entity.getContactNumber());
				dto.setEmailId(entity.getEmailId());
				dto.setFirstName(entity.getFirstName());
				dto.setLastName(entity.getLastName());
				dto.setLoggedIn(entity.getLoggedIn());
				dto.setLoginId(entity.getLoginId());
				dto.setPassword(entity.getPassword());
				usersDto.add(dto);
			});
			response.setUsersDto(usersDto);
			response.setStatusMessage("SUCCESS");
		} catch (Exception e) {
			// TODO: handle exception
			response.setStatusMessage("FAILURE");
		}
		return response;
	}

	@Override
	public UserResponse register(UserRequest request) {
		// TODO Auto-generated method stub
		UserResponse response = new UserResponse();
		UserRoles entity = new UserRoles
 ();
		UsersDto userDto = request.getUserDto();
		try {
			UserRoles userRoles = usersRepo.findByLoginId(userDto.getLoginId());
			List<String> roles = new ArrayList<>();
			roles.add("user");
			if (userRoles == null) {
				entity.setContactNumber(userDto.getContactNumber());
				entity.setEmailId(userDto.getEmailId());
				entity.setFirstName(userDto.getFirstName());
				entity.setLastName(userDto.getLastName());
				entity.setLoggedIn(false);
				entity.setLoginId(userDto.getLoginId());
				entity.setPassword(passwordEncoder().encode(userDto.getPassword()));
				entity.setRoles(roles);
				//entity.setObjectId(new ObjectId());
				usersRepo.save(entity);
				response.setStatusMessage("Success");
			} else {
				response.setStatusMessage("User Already Exists");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			response.setStatusMessage("FAILURE");
		}
		return response;
	}

	@Override
	public UserResponse forgetPassword(UserRequest request) {
		UserResponse response = new UserResponse();
		UsersDto userDto = request.getUserDto();
		try {
			UserRoles userRoles = usersRepo.findByLoginId(userDto.getLoginId());
			if (userRoles != null) {
				userRoles.setPassword(passwordEncoder().encode(userDto.getPassword()));
				usersRepo.save(userRoles);
				response.setStatusMessage("SUCCESS");
			} else {
				response.setStatusMessage("USER NOT FOUND");
			}
		} catch (Exception e) {
			// TODO: handle exception
			response.setStatusMessage("FAILED");
		}
		return response;
	}

	@Override
	public UserResponse searchUsers(String username) {
		UserResponse response = new UserResponse();
		List<UsersDto> users = new ArrayList<UsersDto>();
		try {
			List<UserRoles> entities = usersRepo.searchByIds(username);
			entities.forEach(e -> {
				UsersDto dto = new UsersDto();
				dto.setLoginId(e.getLoginId());
				dto.setFirstName(e.getFirstName());
				dto.setLastName(e.getLastName());
				users.add(dto);
			});
			response.setStatusMessage("SUCCESS");
			response.setUsersDto(users);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return response;
	}

	@Override
	public UserResponse getAllLoggedInUsers() {
		// TODO Auto-generated method stub
//		UserResponse response = new UserResponse();
//		try {
//			List<UserRoles> entities = usersRepo.findAllLoggedIn();
//			// entities.stream().map(UsersDto::new).Collecters.toList();
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
		return null ;
	}
	
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

}
