package com.tweetapp.TweetApp.service;

import java.util.Calendar;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.tweetapp.TweetApp.dto.UserRequest;
import com.tweetapp.TweetApp.dto.UserResponse;
import com.tweetapp.TweetApp.model.UserRoles;
import com.tweetapp.TweetApp.repository.UserRepository;

@Service
@Transactional
public interface UserService {
	
	UserResponse getAllUsers();

	UserResponse register(UserRequest request);

	UserResponse forgetPassword(UserRequest request);

	UserResponse searchUsers(String username);

	UserResponse getAllLoggedInUsers();
	
	
	
	
	
}