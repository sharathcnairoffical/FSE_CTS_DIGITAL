package com.tweetapp.TweetApp.model;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserRoles {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int objectId;

	private String loginId;

	private String firstName;

	private String lastName;

	private String emailId;

	private String password;

	private long contactNumber;

	private Boolean loggedIn;
	
	@Transient
	private List<String> roles;


}
