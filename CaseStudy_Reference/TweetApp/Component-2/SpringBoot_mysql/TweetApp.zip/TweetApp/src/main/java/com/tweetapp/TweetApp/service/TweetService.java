package com.tweetapp.TweetApp.service;

import org.springframework.stereotype.Service;

import com.tweetapp.TweetApp.dto.TweetRequest;
import com.tweetapp.TweetApp.dto.TweetResponse;

@Service
public interface TweetService {
	
	TweetResponse getAllTweets();

	TweetResponse getAllTweetsByUserName(String userName);

	TweetResponse addTweet(TweetRequest request, String userName);

	TweetResponse deleteTweet(String userName, Long tweetId);

	TweetResponse replyToTweet(TweetRequest request);

	TweetResponse likeATweet(TweetRequest request);

	TweetResponse updateTweet(TweetRequest request);

}
