package com.tweetapp.TweetApp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.tweetapp.TweetApp.model.Tweet;

@Repository
public interface TweetRepository extends JpaRepository<Tweet, Integer> {
	


	@Query(nativeQuery=true,value="Select e From Tweet e where e.user_tweet_id = ?1")
	public List<Tweet> findByUserName(String userName);

	//(value="{'tweetId' : ?0}")
	//void deleteByTweetId(Long tweetId);

//	@Query("{ 'tweetId' : ?0 }, { $push : { 'reply' : {reply.1:[{'userId':'bud','replied':'wow'}]}}")
//	void postReply(String tweetId, List<Reply> reply);

	@Query(value="Select e From Tweet e where e.tweetId = ?1")
	//@Query("{'tweetId' : ?0}")
	public Tweet findByTweetId(Long tweetId);
	
	public Tweet findTopByOrderByTweetIdDesc();

	@Query(value="Delete from Tweet t  where t.tweetId=?1")
	public void deleteById(Long tweetId);


}
