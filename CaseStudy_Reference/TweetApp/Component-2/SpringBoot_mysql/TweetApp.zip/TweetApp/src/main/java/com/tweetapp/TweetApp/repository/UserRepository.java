package com.tweetapp.TweetApp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.tweetapp.TweetApp.model.UserRoles;

@Repository
public interface UserRepository extends JpaRepository<UserRoles, Integer> {

	//@Query("{'loginId':?0}")
	@Query(value="Select u From UserRoles u where u.loginId = ?1")
	public UserRoles findByLoginId(String loginId);

	
	@Query(value="Select u From UserRoles u where u.loginId = ?1")
	public List<UserRoles> searchByIds(String username);

//	@Query("{'loggedIn':true}")
//	public List<UserRoles> findAllLoggedIn();

	
	//@Query(value = "select user from User user where user.name = ?1")
	//public User findByUsername(String username);
}
