package com.tweetapp.TweetApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.TweetApp.dto.TweetRequest;
import com.tweetapp.TweetApp.dto.TweetResponse;
//import com.tweetapp.TweetApp.kafka.Producer;
import com.tweetapp.TweetApp.service.TweetService;


import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
public class TweetController {

	@Autowired
	TweetService tweetService;
	
	//public Producer producer;

//    @Autowired
//    TweetController(Producer producer) {
//        this.producer = producer;
//    }

	@GetMapping(value = "/api/v1.0/tweets/all")
	//@CrossOrigin(origins = "http://localhost:3000")
	public TweetResponse getAllTweets() {
		return tweetService.getAllTweets();
	}

	@GetMapping(value = "/api/v1.0/tweets/{username}" )
	//@CrossOrigin(origins = "http://localhost:3000")
	public TweetResponse getAllTweetsUser(@PathVariable("username") String userName) {
		return tweetService.getAllTweetsByUserName(userName);
		
	}
	
	@PostMapping(value = "/api/v1.0/tweets/{username}/add" )
	//@CrossOrigin(origins = "http://localhost:3000")
	public TweetResponse addTweet(@RequestBody TweetRequest request , @PathVariable("username") String userName ) {
//		 this.producer.sendMessage(request.getTweet().getTweet());
		return tweetService.addTweet(request, userName);	
	}
	
	@RequestMapping(path = "/api/v1.0/tweets/{username}/delete/{id}" , method = RequestMethod.DELETE)
	//@CrossOrigin(origins = "http://localhost:3000")
	public TweetResponse deleteTweet(@PathVariable("username") String userName, @PathVariable("id") Long tweetId) {
		return tweetService.deleteTweet(userName,tweetId);
		
	}
	
	@PostMapping(value = "/api/v1.0/tweets/reply" )
	//@CrossOrigin(origins = "http://localhost:3000")
	public TweetResponse replyToTweet(@RequestBody TweetRequest request ) {
		
//		 this.producer.sendMessage(request.getTweet().getReply().get(0).getReplied());
		return tweetService.replyToTweet(request);	
	}
	
	@RequestMapping(value="/api/v1.0/tweets/like",method = RequestMethod.POST)
	//@CrossOrigin(origins = "http://localhost:3000")
	public TweetResponse likeATweet(@RequestBody  TweetRequest request ) {
		return tweetService.likeATweet(request);
	}
	
	@RequestMapping(value="/api/v1.0/tweets/update",method = RequestMethod.POST)
	//@CrossOrigin(origins = "http://localhost:3000")
	public TweetResponse updateTweet(@RequestBody  TweetRequest request ) {
//		 this.producer.sendMessage(request.getTweet().getTweet());
		return tweetService.updateTweet(request);
	}
	
	
}
